package onprogramme.apk.com.article

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
