<?php
    $host = "localhost";
    $dbname = "id17812879_article";
    $user = "id17812879_tutos";
    $pass = "Y{Kc2z?MquUElKe3";
    
    try {
        $db = new PDO("mysql:host=$host; dbname=$dbname", $user, $pass);
        echo "connected";
    } catch (\Throwable $th) {
        echo "Error: ".$th->getMessage();
    }
?>
